var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/submit-intake/route.js")
R.c("server/chunks/[root-of-the-server]__a5805cb5._.js")
R.c("server/chunks/[root-of-the-server]__46d092a4._.js")
R.c("server/chunks/53959_next_f0c023fb._.js")
R.m(13152)
R.m(45215)
module.exports=R.m(45215).exports

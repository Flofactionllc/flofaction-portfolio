var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/wix-collections/route.js")
R.c("server/chunks/[root-of-the-server]__a026d7f9._.js")
R.c("server/chunks/53959_next_f0c023fb._.js")
R.m(14252)
R.m(71817)
module.exports=R.m(71817).exports

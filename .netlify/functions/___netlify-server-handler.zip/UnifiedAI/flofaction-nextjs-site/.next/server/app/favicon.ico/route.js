var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__336795ad._.js")
R.c("server/chunks/53959_next_dist_07362525._.js")
R.c("server/chunks/53959_next_dist_56d6df54._.js")
R.c("server/chunks/53959_next_bf685372._.js")
R.m(46957)
R.m(40381)
module.exports=R.m(40381).exports

module.exports=[62048,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},50559,a=>{"use strict";a.s(["default",()=>b]);let b={src:a.i(62048).default,width:256,height:256}}];

//# sourceMappingURL=UnifiedAI_flofaction-nextjs-site_src_app_4a2eae75._.js.map
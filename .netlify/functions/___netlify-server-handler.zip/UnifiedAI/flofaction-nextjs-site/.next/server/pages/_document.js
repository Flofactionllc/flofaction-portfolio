var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[root-of-the-server]__55aaee41._.js")
R.c("server/chunks/ssr/[root-of-the-server]__cc33dd8e._.js")
R.m(43181)
module.exports=R.m(43181).exports

globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/da09dd3cb77c1dd9.js",
      "static/chunks/79a1cc12575cb817.js",
      "static/chunks/turbopack-ac6dd8488ddaba81.js"
    ],
    "/_error": [
      "static/chunks/490eb857e9fbc11c.js",
      "static/chunks/79a1cc12575cb817.js",
      "static/chunks/turbopack-1b4550cac0611ee5.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/ad20fe274cb33945.js",
    "static/chunks/77db8fc389cf590e.js",
    "static/chunks/51e2cea1e681c2b2.js",
    "static/chunks/f8b4ba88c7ca5371.js",
    "static/chunks/turbopack-bf6bc2ef46bd2ca3.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];